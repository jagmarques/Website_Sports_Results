package com.example.scoredei.controllers;

import com.example.scoredei.api.SportsAPI;
import com.example.scoredei.entity.*;
import com.example.scoredei.service.GameEventService;
import com.example.scoredei.service.SoccerGameService;
import com.example.scoredei.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@Controller
public class MainController {

    @Autowired
    private UserService userService;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private SoccerGameService soccerGameService;
    @Autowired
    private GameEventService gameEventService;

    @GetMapping("/")
    public String viewHomePage()
    {
        return "index";
    }

    @GetMapping("/index")
    public String viewIndexPage()
    {
        return "index";
    }

    @GetMapping("/login")
    public String viewLoginPage(Model model) {
        User user = new User();
        model.addAttribute("user", user);
        return "login";
    }

    @GetMapping("/signup")
    public String viewSignUpPage(Model model) {
        User user = new User();
        model.addAttribute("user",user);
        return "signup";
    }

    @GetMapping("/follow")
    public String viewFollowGamePage(Model model) {
        List<SoccerGame> games = soccerGameService.getAllSoccerGame();
        model.addAttribute("games", games);
        return "follow-game";
    }

    @GetMapping("/follow/{gameId}")
    public String followGame(Model model, @PathVariable("gameId")Integer gameId){
        List<GameEvent> approvedEvents = gameEventService.getApprovedEvents(gameId);
        model.addAttribute("events", approvedEvents);
        return "events";
    }

    @GetMapping("/statistics")
    public String viewStatisticsPage(Model model) {
        List<Team> teams = SportsAPI.getTeams();
        model.addAttribute("teams", teams);
        return "statistics";
    }

    @GetMapping("/statistics/{teamId}")
    public String viewStatisticsPage(Model model, @PathVariable("teamId") Integer teamId) {
        Statistics statistic = SportsAPI.getStatistics(teamId);
        model.addAttribute("statistic", statistic);
        return "team-statistics";
    }

    @PostMapping("/signup")
    public String saveUser(User user, RedirectAttributes redirectAttributes)throws IOException {
        User savedUser = userService.save(user);
        if(savedUser != null) {
            redirectAttributes.addFlashAttribute("message","The user has been saved successfully!");
            return "redirect:/login";
        } else {
            redirectAttributes.addFlashAttribute("message","Unable to save user!");
        }
        return "redirect:/signup";
    }

    @PostMapping("/authorize")
    public String loginUser(User user, RedirectAttributes redirectAttributes, HttpSession session) {
        User loggedInUser = userService.getByEmail(user.getEmail());
        if(loggedInUser != null) {
            if(passwordEncoder.matches(user.getPassword(), loggedInUser.getPassword()) &&
                    loggedInUser.getRole().equalsIgnoreCase("admin")) {
               session.setAttribute("user", loggedInUser);
                return "redirect:/admin";
            } else if(passwordEncoder.matches(user.getPassword(), loggedInUser.getPassword()) &&
                    loggedInUser.getRole().equalsIgnoreCase("user")) {
                session.setAttribute("user", loggedInUser);
                return "redirect:/user";
            }
        }
        redirectAttributes.addFlashAttribute("message","Invalid User Name or Password");
        return "redirect:/login";
    }

    @GetMapping("/403")
    public String getAccessDeniedPage() {
        return "access-denied";
    }



}
