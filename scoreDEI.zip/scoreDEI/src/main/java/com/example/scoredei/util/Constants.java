package com.example.scoredei.util;

public class Constants {
    private static final String START = "Match is Started";
}
