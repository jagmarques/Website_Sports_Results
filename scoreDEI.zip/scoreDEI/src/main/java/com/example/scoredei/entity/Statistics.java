package com.example.scoredei.entity;

public class Statistics {
    private String teamName;

    private int playedHome;
    private int playedAway;
    private int playedTotal;

    private int winHome;
    private int winAway;
    private int winTotal;

    private int drawHome;
    private int  drawAway;
    private int drawTotal;

    private int loseHome;
    private int loseAway;
    private int loseTotal;

    public Statistics() {
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public int getPlayedHome() {
        return playedHome;
    }

    public void setPlayedHome(int playedHome) {
        this.playedHome = playedHome;
    }

    public int getPlayedAway() {
        return playedAway;
    }

    public void setPlayedAway(int playedAway) {
        this.playedAway = playedAway;
    }

    public int getPlayedTotal() {
        return playedTotal;
    }

    public void setPlayedTotal(int playedTotal) {
        this.playedTotal = playedTotal;
    }

    public int getWinHome() {
        return winHome;
    }

    public void setWinHome(int winHome) {
        this.winHome = winHome;
    }

    public int getWinAway() {
        return winAway;
    }

    public void setWinAway(int winAway) {
        this.winAway = winAway;
    }

    public int getWinTotal() {
        return winTotal;
    }

    public void setWinTotal(int winTotal) {
        this.winTotal = winTotal;
    }

    public int getDrawHome() {
        return drawHome;
    }

    public void setDrawHome(int drawHome) {
        this.drawHome = drawHome;
    }

    public int getDrawAway() {
        return drawAway;
    }

    public void setDrawAway(int drawAway) {
        this.drawAway = drawAway;
    }

    public int getDrawTotal() {
        return drawTotal;
    }

    public void setDrawTotal(int drawTotal) {
        this.drawTotal = drawTotal;
    }

    public int getLoseHome() {
        return loseHome;
    }

    public void setLoseHome(int loseHome) {
        this.loseHome = loseHome;
    }

    public int getLoseAway() {
        return loseAway;
    }

    public void setLoseAway(int loseAway) {
        this.loseAway = loseAway;
    }

    public int getLoseTotal() {
        return loseTotal;
    }

    public void setLoseTotal(int loseTotal) {
        this.loseTotal = loseTotal;
    }

    @Override
    public String toString() {
        return "Statistics{" +
                "teamName='" + teamName + '\'' +
                ", playedHome=" + playedHome +
                ", playedAway=" + playedAway +
                ", playedTotal=" + playedTotal +
                ", winHome=" + winHome +
                ", winAway=" + winAway +
                ", winTotal=" + winTotal +
                ", drawHome=" + drawHome +
                ", drawAway=" + drawAway +
                ", drawTotal=" + drawTotal +
                ", loseHome=" + loseHome +
                ", loseAway=" + loseAway +
                ", loseTotal=" + loseTotal +
                '}';
    }
}
