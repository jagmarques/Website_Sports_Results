package com.example.scoredei.api;

import com.example.scoredei.entity.Statistics;
import com.example.scoredei.entity.Team;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class SportsAPI {

    private static String API_KEY = "69cfd582d1192058c2618b006e48d8b1";
    public static Statistics getStatistics(int teamId) {
        Unirest.setTimeouts(0, 0);
        try {
            HttpResponse<String> response = Unirest.get("https://v3.football.api-sports.io/teams/statistics?league=39&season=2021&team="+teamId)
                    .header("x-rapidapi-key", API_KEY)
                    .header("x-rapidapi-host", "v3.football.api-sports.io")
                    .asString();
            JSONObject jsonObject = new JSONObject(response.getBody());
            JSONObject responseObject = jsonObject.getJSONObject("response");
            JSONObject teamObject = responseObject.getJSONObject("team");
            JSONObject fixturesObject = responseObject.getJSONObject("fixtures");
            JSONObject playedObject = fixturesObject.getJSONObject("played");
            JSONObject winsObject = fixturesObject.getJSONObject("wins");
            JSONObject drawsObject = fixturesObject.getJSONObject("draws");
            JSONObject losesObject = fixturesObject.getJSONObject("loses");

            String teamName = teamObject.getString("name");
            int playedHome = playedObject.getInt("home");
            int playedAway = playedObject.getInt("away");
            int playedTotal = playedObject.getInt("total");

            int winsHome = winsObject.getInt("home");
            int winsAway = winsObject.getInt("away");
            int winsTotal = winsObject.getInt("total");

            int drawsHome = drawsObject.getInt("home");
            int drawsAway = drawsObject.getInt("away");
            int drawsTotal = drawsObject.getInt("total");

            int losesHome = losesObject.getInt("home");
            int losesAway = losesObject.getInt("away");
            int losesTotal = losesObject.getInt("total");

            Statistics statistic = new Statistics();
            statistic.setTeamName(teamName);
            statistic.setPlayedHome(playedHome);
            statistic.setPlayedAway(playedAway);
            statistic.setPlayedTotal(playedTotal);
            statistic.setWinHome(winsHome);
            statistic.setWinAway(winsAway);
            statistic.setWinTotal(winsTotal);
            statistic.setDrawHome(drawsHome);
            statistic.setDrawAway(drawsAway);
            statistic.setDrawTotal(drawsTotal);
            statistic.setLoseHome(losesHome);
            statistic.setLoseAway(losesAway);
            statistic.setLoseTotal(losesTotal);

            return statistic;
        } catch (Exception  e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<Team> getTeams() {
        List<Team> teams = new ArrayList<>();
        try {
            Unirest.setTimeouts(0, 0);
            HttpResponse<String> response = Unirest.get("https://v3.football.api-sports.io/teams?league=39&season=2021")
                    .header("x-rapidapi-key", API_KEY)
                    .header("x-rapidapi-host", "v3.football.api-sports.io")
                    .asString();
            JSONObject jsonObject = new JSONObject(response.getBody());
            int numberOfTeams = jsonObject.getInt("results");
            JSONArray responseArray = jsonObject.getJSONArray("response");
            for(int i = 0; i < numberOfTeams; i++) {
                JSONObject responseObject = responseArray.getJSONObject(i);
                JSONObject teamObject = responseObject.getJSONObject("team");
                String teamName = teamObject.getString("name");
                String teamLogo = teamObject.getString("logo");
                int teamId = teamObject.getInt("id");
                Team team = new Team();
                team.setId(teamId);
                team.setName(teamName);
                team.setTeamImage(teamLogo);
                teams.add(team);
            }
            return teams;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return teams;
    }
}
