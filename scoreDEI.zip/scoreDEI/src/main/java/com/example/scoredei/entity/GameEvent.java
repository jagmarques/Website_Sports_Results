package com.example.scoredei.entity;

import javax.persistence.*;

@Entity
@Table(name="event")
public class GameEvent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name="eventType", length = 45)
    private String eventType;
    @Column(name="eventMessage", length = 45)
    private String eventMessage;
    @Column(name="player_id", length = 45)
    private Integer playerId;
    @Column(name="user_id", length = 45)
    private Integer userId;
    @Column(name="game_id", length = 45)
    private Integer gameId;

    @Column(name="approved")
    private boolean approved;

    public GameEvent() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getEventMessage() {
        return eventMessage;
    }

    public void setEventMessage(String eventMessage) {
        this.eventMessage = eventMessage;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getPlayerId() {
        return playerId;
    }

    public void setPlayerId(Integer playerId) {
        this.playerId = playerId;
    }

    public Integer getGameId() {
        return gameId;
    }

    public void setGameId(Integer gameId) {
        this.gameId = gameId;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }


    @Override
    public String toString() {
        return "GameEvent{" +
                "eventType='" + eventType + '\'' +
                ", eventMessage='" + eventMessage + '\'' +
                ", playerId=" + playerId +
                ", userId=" + userId +
                ", gameId=" + gameId +
                ", approved=" + approved +
                '}';
    }
}
