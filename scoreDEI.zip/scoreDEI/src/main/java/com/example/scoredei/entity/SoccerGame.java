package com.example.scoredei.entity;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name="game")
public class SoccerGame {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name="teamAName", length = 45)
    private String teamAName;
    @Column(name="teamBName", length = 45)
    private String teamBName;
    @Column(name="location", length = 45)
    private String location;
    @Column(name="startDate", length = 45)
    private String startDate;
    @Column(name="startTime", length = 45)
    private String startTime;
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name="game_event", joinColumns = @JoinColumn(name="game_id"),
            inverseJoinColumns = @JoinColumn(name="event_id"))
    private Set<GameEvent> gameEvents;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTeamAName() {
        return teamAName;
    }

    public void setTeamAName(String teamAName) {
        this.teamAName = teamAName;
    }

    public String getTeamBName() {
        return teamBName;
    }

    public void setTeamBName(String teamBName) {
        this.teamBName = teamBName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public Set<GameEvent> getGameEvents() {
        return gameEvents;
    }

    public void setGameEvents(Set<GameEvent> gameEvents) {
        this.gameEvents = gameEvents;
    }

    @Override
    public String toString() {
        return "SoccerGame{" +
                "id=" + id +
                ", teamAName='" + teamAName + '\'' +
                ", teamBName='" + teamBName + '\'' +
                ", location='" + location + '\'' +
                ", startDate='" + startDate + '\'' +
                ", startTime='" + startTime + '\'' +
                ", gameEvents=" + gameEvents +
                '}';
    }
}
