package com.example.scoredei.controllers;

import com.example.scoredei.entity.GameEvent;
import com.example.scoredei.entity.Player;
import com.example.scoredei.entity.SoccerGame;
import com.example.scoredei.entity.User;
import com.example.scoredei.service.GameEventService;
import com.example.scoredei.service.PlayerService;
import com.example.scoredei.service.SoccerGameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Controller
public class UserController {
    @Autowired
    private SoccerGameService soccerGameService;
    @Autowired
    private GameEventService gameEventService;
    @Autowired
    private PlayerService playerService;

    private HashMap<String, String> eventMsg = new HashMap<>();


    @GetMapping("/user")
    public String viewUserHomePage(HttpSession session) {
        User loggedInUser = (User) session.getAttribute("user");
        if(loggedInUser != null) {
            if(loggedInUser.getRole() != null) {
                return "/registered/home";
            }
        }

        return "login";
    }

    @GetMapping("/user/games")
    public String viewUserEventPage(HttpSession session, Model model) {
        User loggedInUser = (User) session.getAttribute("user");
        if(loggedInUser != null) {
            if(loggedInUser.getRole() != null) {
                List<SoccerGame> games = soccerGameService.getAllSoccerGame();
                model.addAttribute("games", games);
                return "/registered/games";
            }
        }

        return "login";
    }

    @GetMapping("/user/event/{id}")
    public String viewEventPage(@PathVariable(name="id")Integer id, HttpSession session, Model model) {
        User loggedInUser = (User) session.getAttribute("user");
        if(loggedInUser != null) {
            if(loggedInUser.getRole() != null) {
                GameEvent event = new GameEvent();
                try {
                    SoccerGame game = soccerGameService.get(id);
                    List<Player> players = getAllPlayers(game.getTeamAName(), game.getTeamBName());
                    model.addAttribute("gameEvent", event);
                    model.addAttribute("players", players);
                    model.addAttribute("gameId",id);
                    model.addAttribute("userId", loggedInUser.getId());
                    return "/registered/events";
                }catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
        return "login";
    }

    @PostMapping("/user/save-event")
    public String saveEvent(HttpSession session, GameEvent event, @RequestParam("userId") String userId,
                            @RequestParam("gameId") String gameId) {
        try {
            String playerName = playerService.get(event.getPlayerId()).getName();
            init(playerName);
        }catch(Exception e) {
            System.out.println(e);
        }
        User loggedInUser = (User) session.getAttribute("user");
        if(loggedInUser != null) {
            if(loggedInUser.getRole() != null) {
                event.setGameId(Integer.parseInt(gameId));
                event.setUserId(Integer.parseInt(userId));
                event.setEventMessage(eventMsg.get(event.getEventType()));
                gameEventService.save(event);
                return "redirect:/user/games";
            }
        }
        return "login";
    }

    private void init(String playerName) {
        eventMsg.put("START", "Match is Started");
        eventMsg.put("GOAL", "Player "+playerName+ " Scored a goal");
        eventMsg.put("YELLOW_CARD", "Yellow Card is given to Player "+playerName);
        eventMsg.put("RED_CARD", "Red Card is given to Player "+playerName);
        eventMsg.put("INTERRUPTED_GAME", "Game is Interrupted");
        eventMsg.put("RESUME_GAME", "Game is Resumed");
        eventMsg.put("END", "Game is Ended");
    }

    private List<Player> getAllPlayers(String teamA, String teamB) {
        List<Player> playersOfTeamA = playerService.getPlayersByTeamName(teamA);
        List<Player> playersOfTeamB = playerService.getPlayersByTeamName(teamB);
        List<Player> players = new ArrayList<>();
        for(Player player: playersOfTeamA) {
            players.add(player);
        }
        for(Player player: playersOfTeamB) {
            players.add(player);
        }
        return players;
    }

}
