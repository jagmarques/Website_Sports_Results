package com.example.scoredei.service;

import com.example.scoredei.DAO.TeamRepository;
import com.example.scoredei.entity.Team;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class TeamService {
    @Autowired
    private TeamRepository teamRepository;

    public Team save(Team team) {
        return teamRepository.save(team);
    }

    public List<Team> getAllTeam() {
        return (List<Team>) teamRepository.findAll();
    }

    public Team get(Integer id) throws Exception {
        try {
            return teamRepository.findById(id).get();
        } catch(NoSuchElementException e) {
            System.out.println(e);
            throw new Exception("Couldn't found any Team with ID: "+id);
        }

    }




}
