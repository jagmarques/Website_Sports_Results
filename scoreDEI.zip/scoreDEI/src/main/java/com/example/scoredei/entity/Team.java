package com.example.scoredei.entity;

import javax.persistence.*;

@Entity
@Table(name="team")
public class Team {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name="name", length = 45)
    private String name;
    @Column(name="teamImage", length = 150)
    private String teamImage;

    public Team() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTeamImage() {
        return teamImage;
    }

    public void setTeamImage(String teamImage) {
        this.teamImage = teamImage;
    }

    @Override
    public String toString() {
        return "Team{" +
                "name='" + name + '\'' +
                ", teamImage='" + teamImage + '\'' +
                '}';
    }


    @Transient
    public String getPhotosImagePath() {
        if(id == null || teamImage == null)
            return "/images/logo_3.png";
        if(teamImage.startsWith("http"))
            return this.teamImage;
        return "/team-photos/"+this.name+"/"+this.teamImage;
    }
}
