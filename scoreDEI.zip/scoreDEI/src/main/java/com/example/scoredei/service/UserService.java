package com.example.scoredei.service;

import com.example.scoredei.DAO.UserRepository;
import com.example.scoredei.entity.User;
import com.example.scoredei.util.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;

    public User getByEmail(String email) {
        return userRepository.getUserByEmail(email);
    }

    public List<User> getAllUser()
    {
        return (List<User>) userRepository.findAll(Sort.by("name").ascending());
    }


    public User save(User user) {
        encodePassword(user);
        return userRepository.save(user);
    }

    private void encodePassword(User user) {
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);
    }


    public User get(Integer id) throws UserNotFoundException {
        try {
            return userRepository.findById(id).get();
        } catch(NoSuchElementException e) {
            System.out.println(e);
            throw new UserNotFoundException("Couldn't found any user with ID: "+id);
        }

    }
}
