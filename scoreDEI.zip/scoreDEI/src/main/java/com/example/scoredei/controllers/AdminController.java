package com.example.scoredei.controllers;

import com.example.scoredei.entity.*;
import com.example.scoredei.service.GameEventService;
import com.example.scoredei.service.PlayerService;
import com.example.scoredei.service.SoccerGameService;
import com.example.scoredei.service.TeamService;
import com.example.scoredei.util.FileUploadUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@Controller
public class AdminController {
    @Autowired
    private GameEventService gameEventService;
    @Autowired
    private PlayerService playerService;
    @Autowired
    private SoccerGameService soccerGameService;
    @Autowired
    private TeamService teamService;

    @GetMapping("/admin")
    public String viewAdminHomePage(HttpSession session) {
        User loggedInUser = (User) session.getAttribute("user");
        if(loggedInUser != null) {
           if(loggedInUser.getRole() != null) {
               return "/admin/home";
           }
        }
        return "login";
    }

    @GetMapping("/admin/teams")
    public String viewTeamPage(HttpSession session, Model model) {
        User loggedInUser = (User) session.getAttribute("user");
        if(loggedInUser != null) {
            if(loggedInUser.getRole() != null) {
                List<Team> teams = teamService.getAllTeam();
                model.addAttribute("teams",teams);
                return "/admin/teams";
            }
        }
        return "login";
    }

    @GetMapping("/admin/players")
    public String viewPlayerPage(HttpSession session, Model model) {
        User loggedInUser = (User) session.getAttribute("user");
        if(loggedInUser != null) {
            if(loggedInUser.getRole() != null) {
                List<Player> players = playerService.getAllPlayer();
                model.addAttribute("players", players);
                return "/admin/players";
            }
        }
        return "login";
    }

    @GetMapping("/admin/games")
    public String viewGamePage(HttpSession session, Model model) {
        User loggedInUser = (User) session.getAttribute("user");
        if(loggedInUser != null) {
            if(loggedInUser.getRole() != null) {
                List<SoccerGame> games = soccerGameService.getAllSoccerGame();
                model.addAttribute("games", games);
                return "/admin/games";
            }
        }
        return "login";
    }

    @GetMapping("/admin/approve/{id}")
    public String approveEventPage(@PathVariable(name="id")Integer id,HttpSession session, Model model) {
        User loggedInUser = (User) session.getAttribute("user");
        if(loggedInUser != null) {
            if(loggedInUser.getRole() != null) {
                List<GameEvent> unApprovedEvents = gameEventService.getUnApprovedEvents(id);
                System.out.println(unApprovedEvents);
                model.addAttribute("events", unApprovedEvents);
                return "/admin/approve";
            }
        }
        return "login";
    }

    @GetMapping("/admin/create-game")
    public String createGamePage(HttpSession session, Model model) {
        User loggedInUser = (User) session.getAttribute("user");
        if(loggedInUser != null) {
            if(loggedInUser.getRole() != null) {
                List<Team> teams = teamService.getAllTeam();
                model.addAttribute("teams", teams);
                model.addAttribute("game", new SoccerGame());
                return "/admin/create-game";
            }
        }
        return "login";
    }

    @GetMapping("/admin/create-player")
    public String createPlayerPage(HttpSession session, Model model) {
        User loggedInUser = (User) session.getAttribute("user");
        if(loggedInUser != null) {
            if(loggedInUser.getRole() != null) {
                List<Team> teams = teamService.getAllTeam();
                model.addAttribute("player", new Player());
                model.addAttribute("teams", teams);
                return "/admin/create-player";
            }
        }
        return "login";
    }

    @GetMapping("/admin/create-team")
    public String createTeamPage(HttpSession session, Model model) {
        User loggedInUser = (User) session.getAttribute("user");
        if(loggedInUser != null) {
            if(loggedInUser.getRole() != null) {
                model.addAttribute("team", new Team());
                return "/admin/create-team";
            }
        }
        return "login";
    }

    @PostMapping("/admin/save-team")
    public String saveTeam(HttpSession session, Team team,
                           @RequestParam("image") MultipartFile multipartFile) throws IOException {
        User loggedInUser = (User) session.getAttribute("user");
        if(loggedInUser != null) {
            if(loggedInUser.getRole() != null) {
                if(!multipartFile.isEmpty()) {
                    String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
                    String fileNameOnServer = team.getName() + (fileName.endsWith(".png") ? ".png" : ".jpg");
                    team.setTeamImage(fileNameOnServer);
                    Team savedTeam = teamService.save(team);
                    String uploadDirectory = "team-photos/"+savedTeam.getName();
                    FileUploadUtil.cleanDirectory(uploadDirectory);
                    FileUploadUtil.saveFile(uploadDirectory, fileNameOnServer, multipartFile);
                    return "redirect:/admin/teams";
                } else {
                    return "redirect:/admin/create-team";
                }
            }
        }
        return "login";
    }

    @PostMapping("/admin/save-player")
    public String savePlayer(HttpSession session, Player player) {
        User loggedInUser = (User) session.getAttribute("user");
        System.out.println(player);
        if(loggedInUser != null) {
            if(loggedInUser.getRole() != null) {
                Player savedPlayer = playerService.save(player);
                if(savedPlayer == null) {
                    session.setAttribute("message", "Unable to Save Player");
                    return "redirect:/admin/create-player";
                }
                return "redirect:/admin/players";
            }
        }
        return "login";
    }

    @PostMapping("/admin/save-game")
    public String saveGame(HttpSession session, SoccerGame game) {
        User loggedInUser = (User) session.getAttribute("user");
        if(loggedInUser != null) {
            if(loggedInUser.getRole() != null) {
                SoccerGame savedGame = soccerGameService.save(game);
                if(savedGame == null) {
                    session.setAttribute("message", "Unable to Save Game");
                    return "redirect:/admin/create-game";
                }
                return "redirect:/admin/games";
            }
        }
        return "login";
    }

    @GetMapping("/admin/approve/{gameId}/{eventId}")
    public String approveEvent(HttpSession session, @PathVariable("gameId")Integer gameId,
                               @PathVariable("eventId")Integer eventId) {
        User loggedInUser = (User) session.getAttribute("user");
        if(loggedInUser != null) {
            if(loggedInUser.getRole() != null) {
                gameEventService.updateApprovedStatus(eventId, true);
                return "redirect:/admin/approve/"+gameId;
            }
        }
        return "login";

    }
}
