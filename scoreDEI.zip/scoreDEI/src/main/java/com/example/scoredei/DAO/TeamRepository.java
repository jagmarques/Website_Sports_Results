package com.example.scoredei.DAO;

import com.example.scoredei.entity.Team;
import org.springframework.data.repository.CrudRepository;

public interface TeamRepository extends CrudRepository<Team, Integer> {
}
