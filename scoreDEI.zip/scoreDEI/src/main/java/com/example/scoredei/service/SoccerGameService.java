package com.example.scoredei.service;

import com.example.scoredei.DAO.SoccerGameRepository;
import com.example.scoredei.entity.SoccerGame;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class SoccerGameService {
    @Autowired
    private SoccerGameRepository soccerGameRepository;

    public SoccerGame save(SoccerGame soccerGame) {
        return soccerGameRepository.save(soccerGame);
    }

    public List<SoccerGame> getAllSoccerGame() {
        return (List<SoccerGame>) soccerGameRepository.findAll();
    }

    public SoccerGame get(Integer id) throws Exception {
        try {
            return soccerGameRepository.findById(id).get();
        } catch(NoSuchElementException e) {
            System.out.println(e);
            throw new Exception("Couldn't found any team with ID: "+id);
        }

    }

}
