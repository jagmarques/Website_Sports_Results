package com.example.scoredei.security;

import com.example.scoredei.DAO.UserRepository;
import com.example.scoredei.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class MyUserDetailService implements UserDetailsService {
    @Autowired
    private UserRepository userRepository;
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.getUserByEmail(username);
        if (user != null) {
            return new MyUserDetails(user);
        }
        throw new UsernameNotFoundException("Could not find user with email: "+user);
    }
}
