package com.example.scoredei;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScoreDeiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ScoreDeiApplication.class, args);
    }

}
