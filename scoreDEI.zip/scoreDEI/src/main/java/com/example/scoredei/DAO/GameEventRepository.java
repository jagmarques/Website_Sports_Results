package com.example.scoredei.DAO;

import com.example.scoredei.entity.GameEvent;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import javax.transaction.Transactional;
import java.util.List;

public interface GameEventRepository extends CrudRepository<GameEvent, Integer> {
    @Query("SELECT e FROM GameEvent e WHERE e.gameId= ?1 and e.approved = ?2 ")
    public List<GameEvent> getEvents(Integer id, boolean approved);

    @Query("UPDATE GameEvent e SET e.approved = ?2 WHERE e.id = ?1")
    @Modifying
    @Transactional
    public void updateEnabledStatus(Integer id, boolean enabled);
}
