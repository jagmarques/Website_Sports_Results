package com.example.scoredei.service;

import com.example.scoredei.DAO.GameEventRepository;
import com.example.scoredei.entity.GameEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class GameEventService {
    @Autowired
    private GameEventRepository gameEventRepository;

    public GameEvent save(GameEvent gameEvent) {
        return gameEventRepository.save(gameEvent);
    }


    public List<GameEvent> getUnApprovedEvents(Integer id) {
        return (List<GameEvent>) gameEventRepository.getEvents(id, false);
    }

    public List<GameEvent> getApprovedEvents(Integer id) {
        return (List<GameEvent>) gameEventRepository.getEvents(id, true);
    }

    public void updateApprovedStatus(Integer id, boolean enabled) {
        gameEventRepository.updateEnabledStatus(id, enabled);
    }

    public GameEvent get(Integer id) throws Exception {
        try {
            return gameEventRepository.findById(id).get();
        } catch(NoSuchElementException e) {
            System.out.println(e);
            throw new Exception("Couldn't found any Game Event with ID: "+id);
        }

    }

}
