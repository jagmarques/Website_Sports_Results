package com.example.scoredei.service;

import com.example.scoredei.DAO.PlayerRepository;
import com.example.scoredei.entity.Player;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class PlayerService {
    @Autowired
    private PlayerRepository playerRepository;

    public Player save(Player player) {
        return playerRepository.save(player);
    }

    public List<Player> getAllPlayer() {
        return (List<Player>) playerRepository.findAll();
    }

    public Player get(Integer id) throws Exception {
        try {
            return playerRepository.findById(id).get();
        } catch(NoSuchElementException e) {
            System.out.println(e);
            throw new Exception("Couldn't found any Player with ID: "+id);
        }

    }

    public List<Player> getPlayersByTeamName(String teamName) {
        return playerRepository.getPlayers(teamName);
    }

}
