package com.example.scoredei.DAO;

import com.example.scoredei.entity.SoccerGame;
import org.springframework.data.repository.CrudRepository;

public interface SoccerGameRepository extends CrudRepository<SoccerGame, Integer> {

}
