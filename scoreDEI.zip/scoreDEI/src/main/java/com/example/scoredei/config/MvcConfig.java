package com.example.scoredei.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Path;
import java.nio.file.Paths;

@Configuration
public class MvcConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry resourceHandlerRegistry) {
        String directoryName = "team-photos";
        Path teamPhotosDirectory = Paths.get(directoryName);

        String teamPhotosPath = teamPhotosDirectory.toFile().getAbsolutePath();
        resourceHandlerRegistry.addResourceHandler("/"+directoryName+"/**")
                .addResourceLocations("file:/"+teamPhotosPath+"/");
    }
}
