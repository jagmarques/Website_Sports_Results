package com.example.scoredei.DAO;

import com.example.scoredei.entity.GameEvent;
import com.example.scoredei.entity.Player;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface PlayerRepository extends CrudRepository<Player, Integer> {
    @Query("SELECT p FROM Player p WHERE p.teamName = ?1")
    public List<Player> getPlayers(String teamName);
}
